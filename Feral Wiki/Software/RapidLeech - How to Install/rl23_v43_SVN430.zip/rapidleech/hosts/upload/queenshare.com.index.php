<?php
$upload_services[] = 'queenshare.com';
$max_file_size['queenshare.com'] = 2000; // Filesize limit (MB)
$page_upload['queenshare.com'] = 'queenshare.com.php';
?>