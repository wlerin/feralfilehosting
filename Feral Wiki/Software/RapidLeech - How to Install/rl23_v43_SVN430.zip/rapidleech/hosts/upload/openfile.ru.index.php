<?php
$upload_services[]="openfile.ru";
$max_file_size["openfile.ru"]=900;
$page_upload["openfile.ru"] = "openfile.ru.php";  
?>