<?php
$upload_services[] = 'mega.co.nz_member';
$max_file_size['mega.co.nz_member'] = 2048;
$page_upload['mega.co.nz_member'] = 'mega.co.nz_member.php';
?>