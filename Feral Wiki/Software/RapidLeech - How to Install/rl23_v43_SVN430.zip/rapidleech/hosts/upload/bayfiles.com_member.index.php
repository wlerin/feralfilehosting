<?php
$upload_services[]="bayfiles.com_member";
$max_file_size["bayfiles.com_member"]=5120;
$page_upload["bayfiles.com_member"] = "bayfiles.com_member.php";
?>
