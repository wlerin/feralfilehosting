<?php
$upload_services[] = 'jumbofiles.com';
$max_file_size['jumbofiles.com'] = 1000;
$page_upload['jumbofiles.com'] = 'jumbofiles.com.php';  
?>