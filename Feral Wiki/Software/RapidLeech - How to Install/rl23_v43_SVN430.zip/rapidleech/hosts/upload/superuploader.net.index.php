<?php 
$upload_services[]="superuploader.net";
$max_file_size["superuploader.net"]=1024;
$page_upload["superuploader.net"] = "superuploader.net.php";

?>