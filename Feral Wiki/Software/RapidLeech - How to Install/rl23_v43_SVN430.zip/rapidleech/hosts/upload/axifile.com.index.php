<?php
$upload_services[] = "axifile.com";
$max_file_size["axifile.com"] = 200;
$page_upload["axifile.com"] = "axifile.com.php";  
?>