<?php 
$upload_services[] = "rapidshare.com_2GB";
$max_file_size["rapidshare.com_2GB"] = 2048;
$page_upload["rapidshare.com_2GB"] = "rapidshare.com_2GB.php";
?>