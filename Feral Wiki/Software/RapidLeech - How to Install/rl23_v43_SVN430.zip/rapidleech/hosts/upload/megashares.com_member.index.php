<?php
$upload_services[] = "megashares.com_member";
$max_file_size["megashares.com_member"] = 2000; // Max 10000
$page_upload["megashares.com_member"] = "megashares.com_member.php";
?>