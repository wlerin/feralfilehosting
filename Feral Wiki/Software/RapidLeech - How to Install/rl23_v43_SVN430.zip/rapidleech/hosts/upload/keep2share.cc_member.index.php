<?php
$upload_services[] = 'keep2share.cc_member';
$max_file_size['keep2share.cc_member'] = 1000;
$page_upload['keep2share.cc_member'] = 'keep2share.cc_member.php';
?>