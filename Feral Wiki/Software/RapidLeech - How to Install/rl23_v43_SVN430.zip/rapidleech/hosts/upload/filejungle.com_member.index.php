<?php 
$upload_services[] = "filejungle.com_member";
$max_file_size["filejungle.com_member"] = 2048;
$page_upload["filejungle.com_member"] = "filejungle.com_member.php";
?>