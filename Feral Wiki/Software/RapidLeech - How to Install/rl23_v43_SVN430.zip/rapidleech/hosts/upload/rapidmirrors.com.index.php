<?php
$upload_services[]="rapidmirrors.com";
$max_file_size["rapidmirrors.com"]=100;
$page_upload["rapidmirrors.com"] = "rapidmirrors.com.php";  
?>