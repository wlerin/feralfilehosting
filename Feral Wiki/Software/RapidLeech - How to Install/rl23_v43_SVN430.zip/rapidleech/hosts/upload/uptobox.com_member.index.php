<?php 
$upload_services[]="uptobox.com_member";
$max_file_size["uptobox.com_member"]= 2048;
$page_upload["uptobox.com_member"] = "uptobox.com_member.php";  
?>