<?php 
$upload_services[]="minus.com";
$max_file_size["minus.com"]=2048;
$page_upload["minus.com"] = "minus.com.php";  
?>
