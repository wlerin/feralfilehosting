<?php
$upload_services[] = "netkups.com";
$max_file_size["netkups.com"] = 1000;
$page_upload["netkups.com"] = "netkups.com.php";
?>