<?php
$upload_services[]="sendmyway.com_member";
$max_file_size["sendmyway.com_member"]=1000;
$page_upload["sendmyway.com_member"] = "sendmyway.com_member.php";  
?>