<?php
$upload_services[] = "rapidshare.com_member";
$max_file_size["rapidshare.com_member"] = 1024;
$page_upload["rapidshare.com_member"] = "rapidshare.com_member.php";
?>