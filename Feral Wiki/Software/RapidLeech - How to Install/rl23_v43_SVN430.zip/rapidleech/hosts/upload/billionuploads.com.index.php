<?php
$upload_services[] = 'billionuploads.com';
$max_file_size['billionuploads.com'] = 2000; // Filesize limit (MB)
$page_upload['billionuploads.com'] = 'billionuploads.com.php';
?>