<?php
$upload_services[]="g.zhubajie.com";
$max_file_size["g.zhubajie.com"]=200;
$page_upload["g.zhubajie.com"] = "g.zhubajie.com.php";  
?>