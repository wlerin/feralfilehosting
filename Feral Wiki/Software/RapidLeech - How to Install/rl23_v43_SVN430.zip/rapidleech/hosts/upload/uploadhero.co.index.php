<?php
$upload_services[] = "uploadhero.co";
$max_file_size["uploadhero.co"] = 1024;
$page_upload["uploadhero.co"] = "uploadhero.co.php";
?>